from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
#from DB_Operations import add_text, get_data
import re
import sys
import os.path
  
  
app = Flask(__name__, template_folder='./templates', static_folder='./staticFiles')
app.secret_key = 'xyzsdfg'
  
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '123456'
app.config['MYSQL_DB'] = 'user_system'
  
mysql = MySQL(app)

@app.route('/')
@app.route('/index', methods =['GET', 'POST'])
def index():
    
    return render_template('index.html')


@app.route('/students_youngster', methods =['GET', 'POST'])
def students_youngster():
    
    if request.method == 'POST' and 'name' in request.form and 'age' in request.form and 'password' in request.form and 'username' in request.form and 'status' in request.form and 'studied' in request.form and 'email' in request.form and 'phone' in request.form:
        name = request.form['name']
        age = request.form['age']
        password = request.form['password']
        username = request.form['username']
        status = request.form['status']
        phone = request.form['phone']
        email = request.form['email']
        studied = request.form['studied']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO user VALUES (%s, %s, %s, %s, %s, %s, %s, %s)', (name, age, password, username, status, studied, email, phone ))
        mysql.connection.commit()
        cursor.close()
       
    return render_template('students_youngster.html')


@app.route('/ngo_business', methods =['GET', 'POST'])
def ngo_business():

    if request.method == 'POST' and 'location' in request.form and 'description' in request.form and 'email' in request.form and 'phone' in request.form:
        location = request.form['location']
        description = request.form['description']
        phone = request.form['phone']
        email = request.form['email']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO business VALUES (%s, %s, %s, %s)', (location, description, email, phone ))
        mysql.connection.commit()
        cursor.close()
    
    return render_template('ngo_business.html')

@app.route('/profilpage', methods =['GET', 'POST'])
def profilpage():
   
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("SELECT * FROM user")
    records = cursor.fetchall()
    mysql.connection.commit()
    cursor.close()
    return render_template('profilpage.html', text=records[0])
 

@app.route('/profilpage_business', methods =['GET', 'POST'])
def profilpage_business():
   
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("SELECT * FROM business")
    records = cursor.fetchall()
    mysql.connection.commit()
    cursor.close()
    return render_template('profilpage_business.html', text=records[0])


    
if __name__ == '__main__':
    app.debug = True
    #app.run()
    app.run(host='0.0.0.0', port=5000)
